import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pet } from '../classes/pet';

@Injectable({
  providedIn: 'root'
})

export class PetService {

  private url: string = 'http://localhost:8080/pets'

  constructor(private http: HttpClient) { }

  // Get Pets by ownerId
  getPetsByOwnerId(ownerId: number): Observable<Pet[]> {
    return this.http.get<Pet[]>(`${this.url}/owner/${ownerId}`);
  }

  // Add a new pet to a specific owner
  addPet(ownerId: number, pet: Pet): Observable<Pet> {
    return this.http.post<Pet>(`${this.url}/owner/${ownerId}`, pet);
  }

  // Update a pet's details
  updatePet(petId: number, pet: Pet): Observable<Pet> {
    return this.http.put<Pet>(`${this.url}/${petId}`, pet);
  }

  // Delete a pet by pet ID
  deletePet(petId: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/${petId}`);
  }

  // Get all Pets
  getAllPet(): Observable<Pet[]>{
    return this.http.get<Pet[]>(this.url)
  }

  // Get a Pet by id
  getPet(id: number): Observable<Pet> {
    return this.http.get<Pet>(`${this.url}/${id}`);
  }

  // Fetch pets with status: true
  getLostPets(): Observable<Pet[]> {
    return this.http.get<Pet[]>(`${this.url}/lost`);
  }

}
