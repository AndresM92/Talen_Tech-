import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Owner } from '../classes/owner';

@Injectable({
  providedIn: 'root'
})

export class OwnerService {

  private url: string = 'http://localhost:8080/owners'

  constructor(private http: HttpClient) { }

  // Get all Owners
  getAllOwner(): Observable<Owner[]>{
    return this.http.get<Owner[]>(this.url)
  }

  // Create an Owner
  createOwner(data: Owner): Observable<Owner> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.post<Owner>(this.url, data, { headers });
  }

  // Update an Owner
  updateOwner(id: number, data: Owner): Observable<Owner> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.put<Owner>(`${this.url}/${id}`, data, { headers });
  }

  // Delete an Owner
  deleteOwner(id: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/${id}`);
  }

  // Get an Owner by id
  getOwner(id: number): Observable<Owner> {
    return this.http.get<Owner>(`${this.url}/${id}`);
  }
}
