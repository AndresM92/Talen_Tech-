import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Discount } from '../classes/discount';

@Injectable({
  providedIn: 'root'
})

export class DiscountService {

  private url: string = 'http://localhost:8080/discounts'

  constructor(private http: HttpClient) { }

  // Get all Discounts
  getAllDiscount(): Observable<Discount[]>{
    return this.http.get<Discount[]>(this.url)
  }

  // Create a Discount
  createDiscount(data: Discount): Observable<Discount> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.post<Discount>(this.url, data, { headers });
  }

  // Update a Discount
  updateDiscount(id: number, data: Discount): Observable<Discount> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.put<Discount>(`${this.url}/${id}`, data, { headers });
  }

  // Delete a Discount
  deleteDiscount(id: number): Observable<void> {
    return this.http.delete<void>(`${this.url}/${id}`);
  }

  // Get a Discount by id
  getDiscount(id: number): Observable<Discount> {
    return this.http.get<Discount>(`${this.url}/${id}`);
  }
}
