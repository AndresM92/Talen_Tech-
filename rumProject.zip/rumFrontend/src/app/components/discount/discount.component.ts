import { Component, OnInit } from '@angular/core';
import { DiscountService } from '../../services/discount.service';
import { Discount } from '../../classes/discount';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-discount',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './discount.component.html',
  styleUrl: './discount.component.css'
})

export class DiscountComponent implements OnInit {
  discounts: Discount[] = [];
  selectedDiscount: Discount | null = null;  // For updating discounts
  newDiscount: Discount = new Discount('', '', ''); // Form for new discount

  constructor(private discountService: DiscountService) {}

  ngOnInit(): void {
    this.loadDiscounts();
  }

  // Load all discounts from backend
  loadDiscounts(): void {
    this.discountService.getAllDiscount().subscribe(
      (data) => this.discounts = data,
      (error) => console.error('Error fetching discounts:', error)
    );
  }

  // Create a new discount
  addDiscount(): void {
    this.discountService.createDiscount(this.newDiscount).subscribe(
      (data) => {
        this.discounts.push(data);
        this.newDiscount = new Discount('', '', ''); // Reset form
      },
      (error) => console.error('Error adding discount:', error)
    );
  }

  // Set a discount for updating
  editDiscount(discount: Discount): void {
    this.selectedDiscount = { ...discount }; // Copy the discount for editing
  }

  // Update the selected discount
  updateDiscount(): void {
    if (this.selectedDiscount && this.selectedDiscount.discountId) {
      this.discountService.updateDiscount(this.selectedDiscount.discountId, this.selectedDiscount).subscribe(
        (updatedDiscount) => {
          const index = this.discounts.findIndex(d => d.discountId === updatedDiscount.discountId);
          if (index > -1) this.discounts[index] = updatedDiscount;
          this.selectedDiscount = null; // Clear selected discount
        },
        (error) => console.error('Error updating discount:', error)
      );
    }
  }

  // Delete a discount
  deleteDiscount(discountId: number): void {
    this.discountService.deleteDiscount(discountId).subscribe(
      () => this.discounts = this.discounts.filter(d => d.discountId !== discountId),
      (error) => console.error('Error deleting discount:', error)
    );
  }

}
