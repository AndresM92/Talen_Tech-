import { Component, OnInit } from '@angular/core';
import { OwnerService } from '../../services/owner.service';
import { DocType } from '../../models/doc-type.model';
import { OwnerGender } from '../../models/owner-gender.model'
import { City } from "../../models/city.model";
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-owner',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule],
  templateUrl: './owner.component.html',
  styleUrl: './owner.component.css'
})

export class OwnerComponent implements OnInit {
  ownerForm: FormGroup;
  owners: any[] = [];
  docTypes = Object.values(DocType);
  genders = Object.values(OwnerGender);
  cities = Object.values(City);

  editingOwnerId: number | null = null;

  constructor(private fb: FormBuilder, private ownerService: OwnerService) {
    this.ownerForm = this.fb.group({
      docType: [''],
      docNumber: [''],
      firstName: [''],
      lastName: [''],
      ownerGender: [''],
      ownerCity: [''],
      ownerAddress: [''],
      ownerPhonenumber: [''],
      ownerEmail: [''],
      password: [''],
      ownerPhoto: ['']
    });
  }

  ngOnInit(): void {
    this.loadOwners();
  }

  // Get all Owners
  loadOwners(): void {
    this.ownerService.getAllOwner().subscribe((data: any[]) => {
      this.owners = data;
    });
  }

  // Handles form submission, either creating or updating an owner.
  onSubmit(): void {
    const ownerData = this.ownerForm.value; // Get the form values
    console.log('Owner data to submit:', JSON.stringify(ownerData, null, 2)); // Log formatted JSON

    if (this.editingOwnerId) {
        this.ownerService.updateOwner(this.editingOwnerId, ownerData).subscribe(() => {
            this.loadOwners();
            this.ownerForm.reset();
            this.editingOwnerId = null;
        });
    } else {
        this.ownerService.createOwner(ownerData).subscribe(() => {
            this.loadOwners();
            this.ownerForm.reset();
        });
    }
  }

  // Patches the form with an existing owner's data, allowing inline editing.
  onEdit(owner: any): void {
    this.ownerForm.patchValue(owner);
    this.editingOwnerId = owner.ownerId;
  }

  // Delete an Owner by Id
  onDelete(ownerId: number): void {
    this.ownerService.deleteOwner(ownerId).subscribe(() => {
      this.loadOwners();
    });
  }
}
