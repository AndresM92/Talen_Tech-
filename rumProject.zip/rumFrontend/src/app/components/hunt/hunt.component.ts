import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { PetService } from '../../services/pet.service';
import { Pet } from '../../classes/pet';

@Component({
  selector: 'app-hunt',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './hunt.component.html',
  styleUrl: './hunt.component.css'
})
export class HuntComponent implements OnInit {
  lostPets: Pet[] = [];

  constructor(private petService: PetService) {}

  ngOnInit(): void {
    this.loadLostPets();
  }

  loadLostPets(): void {
    this.petService.getLostPets().subscribe(
      (pets: Pet[]) => {
        this.lostPets = pets;
      },
      (error) => {
        console.error('Error fetching lost pets', error);
      }
    );
  }
}
