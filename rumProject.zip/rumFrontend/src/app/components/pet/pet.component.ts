import { Component, OnInit } from '@angular/core';
import { PetService } from '../../services/pet.service';
import { Pet } from '../../classes/pet';
import { Species } from '../../models/species.model';
import { Breed } from '../../models/breed.model';
import { PetGender } from '../../models/pet-gender.model';
import { City } from '../../models/city.model';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-pet',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule, FormsModule],
  templateUrl: './pet.component.html',
  styleUrl: './pet.component.css'
})

export class PetComponent {
  pets: Pet[] = [];
  ownerId?: number; // Set dynamically based on user input
  ownerIdInput: number | null = null; // Temporary input value for ownerId
  newPet: Pet = this.initializePet();
  editingPet: Pet | null = null;

  speciesOptions = Object.values(Species);
  breedOptions = Object.values(Breed);
  petGenderOptions = Object.values(PetGender);
  cityOptions = Object.values(City);

  constructor(private petService: PetService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    // Get ownerId from route parameters
    this.route.paramMap.subscribe(params => {
      const ownerId = params.get('ownerId');
      if (ownerId) {
        this.ownerId = +ownerId; // Convert string to number
        this.loadPets(); // Load pets for the specified owner
      }
    });
  }

  loadPets(): void {
    if (this.ownerId != null) {
      this.petService.getPetsByOwnerId(this.ownerId).subscribe((pets) => {
        this.pets = pets;
      });
    }
  }

  selectOwner(): void {
    if (this.ownerIdInput != null) {
      this.ownerId = this.ownerIdInput;
      this.loadPets();
    }
  }

  addPet(): void {
    if (this.ownerId != null && this.newPet.petName) {
      console.log('Sending Pet Data:', JSON.stringify(this.newPet, null, 2));
      this.petService.addPet(this.ownerId, this.newPet).subscribe(() => {
        this.loadPets();
        this.newPet = this.initializePet();  // Reset form after adding
      });
    }
  }

  editPet(pet: Pet): void {
    this.editingPet = { ...pet };  // Clone pet to avoid direct editing
  }

  updatePet(): void {
    if (this.editingPet && this.editingPet.petId != null) {
      this.petService.updatePet(this.editingPet.petId, this.editingPet).subscribe(() => {
        this.loadPets();
        this.editingPet = null;  // Exit edit mode
      });
    }
  }

  deletePet(petId: number): void {
    if (this.ownerId != null) {
      this.petService.deletePet(petId).subscribe(() => {
        this.loadPets();
      });
    }
  }

  cancelEdit(): void {
    this.editingPet = null;
  }

  private initializePet(): Pet {
    return {
      petName: '',
      petSpecies: Species.PERRO,
      petBreed: Breed.BEAGLE,
      petGender: PetGender.MACHO,
      petCity: City.CITY1,
      petAge: 0,
      status: true
    };
  }
}
