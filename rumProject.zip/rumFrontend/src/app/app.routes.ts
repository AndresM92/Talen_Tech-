import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DiscountComponent } from "./components/discount/discount.component";
import { OwnerComponent } from "./components/owner/owner.component";
import { PetComponent } from "./components/pet/pet.component";
import { HomeComponent } from "./components/home/home.component";
import { HuntComponent } from "./components/hunt/hunt.component";

export const routes: Routes = [
    {
        path:"discounts",
        component:DiscountComponent
    },
    {
        path:"users",
        component:OwnerComponent
    },
    {
        path:"pets",
        component:PetComponent
    },
    {
        path:"pets/users/:ownerId",
        component: PetComponent
    },
    {
        path:"hunt",
        component: HuntComponent
    },
    {
        path:"home",
        component: HomeComponent
    },
    {
        path:"",
        component: HomeComponent
    },
    {
        path: '**',
        redirectTo: '',
        pathMatch: 'full'
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule {}
