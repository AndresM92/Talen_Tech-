import { Owner } from './owner';

describe('Owner', () => {
  it('should create an instance', () => {
    expect(new Owner()).toBeTruthy();
  });
});
