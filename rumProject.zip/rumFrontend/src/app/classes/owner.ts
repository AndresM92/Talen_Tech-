import { DocType } from "../models/doc-type.model";
import { OwnerGender } from "../models/owner-gender.model";
import { City } from "../models/city.model";

export class Owner {

    constructor(
        docType: DocType,
        docNumber: string,
        firstName: string,
        lastName: string,
        ownerGender: OwnerGender,
        ownerCity: City,
        ownerAddress: string,
        ownerPhonenumber: string,
        ownerEmail: string,
        password: string,
        ownerPhoto?: string,
        ownerId?: number
    ){}
}
