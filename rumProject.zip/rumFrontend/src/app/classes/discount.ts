export class Discount {
    discountId?: number;
    discountDescription: string;
    validFrom: string;
    validTo: string;

    constructor(
        discountDescription: string,
        validFrom: string,
        validTo: string,
        discountId?: number
    ){
        this.discountDescription = discountDescription;
        this.validFrom = validFrom;
        this.validTo = validTo;
        if (discountId) this.discountId = discountId;
    }
}
