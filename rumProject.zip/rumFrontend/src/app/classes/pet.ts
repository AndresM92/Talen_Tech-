import { Species } from "../models/species.model";
import { Breed } from "../models/breed.model";
import { PetGender } from "../models/pet-gender.model";
import { City } from "../models/city.model";

export class Pet {
    petName: string;
    petSpecies: Species;
    petBreed: Breed;
    petGender: PetGender;
    petCity: City;
    petAge: number;
    status: boolean;
    petPhoto?: string;
    petId?: number;

    constructor(
        petName: string,
        petSpecies: Species,
        petBreed: Breed,
        petGender: PetGender,
        petCity: City,
        petAge: number,
        status: boolean,
        petPhoto?: string,
        petId?: number
    ){
        this.petName = petName;
        this.petSpecies = petSpecies;
        this.petBreed = petBreed;
        this.petGender = petGender;
        this.petCity = petCity;
        this.petAge = petAge;
        this.status = status;
        if (petPhoto) this.petPhoto = petPhoto;
        if (petId) this.petId = petId;
    }
}
