export enum City {
    CITY1 = 'CITY1',
    CITY2 = 'CITY2',
    CITY3 = 'CITY3',
}
