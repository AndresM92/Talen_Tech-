export enum Species {
    PERRO = 'PERRO',
    GATO = 'GATO',
    AVE = 'AVE',
    PEZ = 'PEZ',
    CONEJO = 'CONEJO',
    HAMSTER = 'HAMSTER',
    CABRA = 'CABRA'
}
