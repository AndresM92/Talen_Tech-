export enum PetGender {
    MACHO = 'MACHO',
    HEMBRA = 'HEMBRA',
}
