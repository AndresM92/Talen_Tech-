package com.rum.rumBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RumBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
