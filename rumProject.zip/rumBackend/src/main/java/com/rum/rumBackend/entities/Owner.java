package com.rum.rumBackend.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Owner {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ownerId;

    @Enumerated(EnumType.STRING)
    private DocType docType;

    @Column(nullable = false, unique = true)
    private String docNumber;

    @Column(nullable = false, length = 120)
    private String firstName;

    @Column(nullable = false, length = 120)
    private String lastName;

    @Enumerated(EnumType.STRING)
    private OwnerGender ownerGender;

    @Enumerated(EnumType.STRING)
    private City ownerCity;

    @Column(nullable = false)
    private String ownerAddress;

    @Column(nullable = false)
    private String ownerPhonenumber;

    @Column(nullable = false, unique = true)
    private String ownerEmail;

    @Column(nullable = false)
    private String password;

    @Column(nullable = true)
    private String ownerPhoto;

    @OneToMany(mappedBy = "owner", targetEntity = Pet.class, fetch = FetchType.LAZY)
    private List<Pet> pets;


    public Owner () { }


    public Owner(Long ownerId, DocType docType, String docNumber, String firstName, String lastName, OwnerGender ownerGender, City ownerCity, String ownerAddress, String ownerPhonenumber, String ownerEmail, String password, String ownerPhoto, List<Pet> pets) {
        this.ownerId = ownerId;
        this.docType = docType;
        this.docNumber = docNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.ownerGender = ownerGender;
        this.ownerCity = ownerCity;
        this.ownerAddress = ownerAddress;
        this.ownerPhonenumber = ownerPhonenumber;
        this.ownerEmail = ownerEmail;
        this.password = password;
        this.ownerPhoto = ownerPhoto;
        this.pets = pets;
    }


    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public DocType getDocType() {
        return docType;
    }

    public void setDocType(DocType docType) {
        this.docType = docType;
    }

    public String getDocNumber() {
        return docNumber;
    }

    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public OwnerGender getOwnerGender() {
        return ownerGender;
    }

    public void setOwnerGender(OwnerGender ownerGender) {
        this.ownerGender = ownerGender;
    }

    public City getOwnerCity() {
        return ownerCity;
    }

    public void setOwnerCity(City ownerCity) {
        this.ownerCity = ownerCity;
    }

    public String getOwnerAddress() {
        return ownerAddress;
    }

    public void setOwnerAddress(String ownerAddress) {
        this.ownerAddress = ownerAddress;
    }

    public String getOwnerPhonenumber() {
        return ownerPhonenumber;
    }

    public void setOwnerPhonenumber(String ownerPhonenumber) {
        this.ownerPhonenumber = ownerPhonenumber;
    }

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getOwnerPhoto() {
        return ownerPhoto;
    }

    public void setOwnerPhoto(String ownerPhoto) {
        this.ownerPhoto = ownerPhoto;
    }


    @Override
    public String toString() {
        return "Owner{" +
                "ownerId=" + ownerId +
                ", docType=" + docType +
                ", docNumber='" + docNumber + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", ownerGender=" + ownerGender +
                ", ownerAddress='" + ownerAddress + '\'' +
                ", ownerPhonenumber='" + ownerPhonenumber + '\'' +
                ", ownerEmail='" + ownerEmail + '\'' +
                ", password='" + password + '\'' +
                ", ownerPhoto='" + ownerPhoto + '\'' +
                '}';
    }
}
