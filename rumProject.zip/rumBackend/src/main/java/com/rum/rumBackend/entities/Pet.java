package com.rum.rumBackend.entities;

import jakarta.persistence.*;

@Entity
public class Pet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long petId;

    @Column(nullable = false, length = 60)
    private String petName;

    @Enumerated(EnumType.STRING)
    private Species petSpecies;

    @Enumerated(EnumType.STRING)
    private Breed petBreed;

    @Enumerated(EnumType.STRING)
    private PetGender petGender;

    @Enumerated(EnumType.STRING)
    private City petCity;

    @Column(nullable = false)
    private Byte petAge;

    @Column(nullable = false)
    private Boolean status;

    @Column(nullable = true)
    private String petPhoto;

    @ManyToOne
    @JoinColumn(name = "owner", nullable = false)
    private Owner owner;


    public Pet() { }


    public Pet(Long petId, String petName, Species petSpecies, Breed petBreed, PetGender petGender, City petCity, Byte petAge, Boolean status, String petPhoto, Owner owner) {
        this.petId = petId;
        this.petName = petName;
        this.petSpecies = petSpecies;
        this.petBreed = petBreed;
        this.petGender = petGender;
        this.petCity = petCity;
        this.petAge = petAge;
        this.status = status;
        this.petPhoto = petPhoto;
        this.owner = owner;
    }


    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    // Manually defining the getter
    public Owner getOwner() {
        return owner;
    }

    public Long getPetId() {
        return petId;
    }

    public void setPetId(Long petId) {
        this.petId = petId;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public Species getPetSpecies() {
        return petSpecies;
    }

    public void setPetSpecies(Species petSpecies) {
        this.petSpecies = petSpecies;
    }

    public Breed getPetBreed() {
        return petBreed;
    }

    public void setPetBreed(Breed petBreed) {
        this.petBreed = petBreed;
    }

    public PetGender getPetGender() {
        return petGender;
    }

    public void setPetGender(PetGender petGender) {
        this.petGender = petGender;
    }

    public City getPetCity() {
        return petCity;
    }

    public void setPetCity(City petCity) {
        this.petCity = petCity;
    }

    public Byte getPetAge() {
        return petAge;
    }

    public void setPetAge(Byte petAge) {
        this.petAge = petAge;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getPetPhoto() {
        return petPhoto;
    }

    public void setPetPhoto(String petPhoto) {
        this.petPhoto = petPhoto;
    }


    @Override
    public String toString() {
        return "Pet{" +
                "petId=" + petId +
                ", petName='" + petName + '\'' +
                ", petSpecies=" + petSpecies +
                ", petBreed=" + petBreed +
                ", petGender=" + petGender +
                ", petAge=" + petAge +
                ", status=" + status +
                ", petPhoto='" + petPhoto + '\'' +
                '}';
    }
}
