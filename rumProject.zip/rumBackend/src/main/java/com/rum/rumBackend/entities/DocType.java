package com.rum.rumBackend.entities;

public enum DocType {
    TARJETA_IDENTIDAD,
    CEDULA_CIUDADANIA,
    CONTRASENA_REGISTRADURIA,
    PASAPORTE_COLOMBIANO,
    REGISTRO_CIVIL
}
