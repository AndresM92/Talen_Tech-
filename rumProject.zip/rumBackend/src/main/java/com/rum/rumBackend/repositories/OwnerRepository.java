package com.rum.rumBackend.repositories;

import com.rum.rumBackend.entities.Owner;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OwnerRepository extends JpaRepository<Owner, String> {
    // Custom Queries
}
