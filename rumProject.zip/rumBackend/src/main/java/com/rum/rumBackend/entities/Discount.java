package com.rum.rumBackend.entities;

import jakarta.persistence.*;
import java.time.LocalDate;


@Entity
public class Discount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long discountId;

    @Column(nullable = false)
    private String discountDescription;

    @Column(nullable = false)
    private LocalDate validFrom;

    @Column(nullable = false)
    private LocalDate validTo;


    public Discount() { }


    public Discount(Long discountId, String discountDescription, LocalDate validFrom, LocalDate validTo) {
        this.discountId = discountId;
        this.discountDescription = discountDescription;
        this.validFrom = validFrom;
        this.validTo = validTo;
    }

    public Long getDiscountId() {
        return discountId;
    }

    public void setDiscountId(Long discountId) {
        this.discountId = discountId;
    }

    public String getDiscountDescription() {
        return discountDescription;
    }

    public void setDiscountDescription(String discountDescription) {
        this.discountDescription = discountDescription;
    }

    public LocalDate getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(LocalDate validFrom) {
        this.validFrom = validFrom;
    }

    public LocalDate getValidTo() {
        return validTo;
    }

    public void setValidTo(LocalDate validTo) {
        this.validTo = validTo;
    }


    @Override
    public String toString() {
        return "Discount{" +
                "discountId=" + discountId +
                ", discountDescription='" + discountDescription + '\'' +
                ", validFrom=" + validFrom +
                ", validTo=" + validTo +
                '}';
    }
}
