package com.rum.rumBackend.services;

import com.rum.rumBackend.entities.Pet;
import com.rum.rumBackend.entities.Owner;
import com.rum.rumBackend.repositories.PetRepository;
import com.rum.rumBackend.repositories.OwnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class PetService {

    @Autowired
    private PetRepository petRepository;

    @Autowired
    private OwnerRepository ownerRepository;

    // Get all pets
    public List<Pet> getAllPets() {
        return petRepository.findAll();
    }

    // Get pets by owner ID
    public List<Pet> getPetsByOwnerId(Long ownerId) {
        Owner owner = ownerRepository.findById(String.valueOf(ownerId))
                .orElseThrow(() -> new RuntimeException("Owner not found with id " + ownerId));
        return petRepository.findByOwner(owner);
    }

    // Add new pet for a specific owner
    public Pet addPet(Long ownerId, Pet pet) {
        Owner owner = ownerRepository.findById(String.valueOf(ownerId))
                .orElseThrow(() -> new RuntimeException("Owner not found with id " + ownerId));
        pet.setOwner(owner);
        return petRepository.save(pet);
    }

    // Get all lost pets
    public List<Pet> getLostPets() {
        return petRepository.findByStatus(true);
    }

    // Update pet by pet ID
    public Pet updatePet(Long petId, Pet petDetails) {
        Pet pet = petRepository.findById(String.valueOf(petId))
                .orElseThrow(() -> new RuntimeException("Pet not found with id " + petId));

        pet.setPetName(petDetails.getPetName());
        pet.setPetSpecies(petDetails.getPetSpecies());
        pet.setPetBreed(petDetails.getPetBreed());
        pet.setPetGender(petDetails.getPetGender());
        pet.setPetAge(petDetails.getPetAge());
        pet.setStatus(petDetails.getStatus());
        pet.setPetPhoto(petDetails.getPetPhoto());

        return petRepository.save(pet);
    }

    // Delete pet by pet ID
    public void deletePet(Long petId) {
        Pet pet = petRepository.findById(String.valueOf(petId))
                .orElseThrow(() -> new RuntimeException("Pet not found with id " + petId));
        petRepository.delete(pet);
    }
}
