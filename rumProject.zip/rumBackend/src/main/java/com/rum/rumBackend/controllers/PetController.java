package com.rum.rumBackend.controllers;

import com.rum.rumBackend.entities.Pet;
import com.rum.rumBackend.services.PetService;
import com.rum.rumBackend.repositories.PetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/pets")
@CrossOrigin(origins = "http://localhost:4200")
public class PetController {

    @Autowired
    private PetService petService;

    @Autowired
    private PetRepository petRepository;

    // Get all pets
    @GetMapping
    public List<Pet> getAllPets() {
        return petService.getAllPets();
    }

    // Get pets by owner ID
    @GetMapping("/owner/{ownerId}")
    public List<Pet> getPetsByOwnerId(@PathVariable Long ownerId) {
        return petService.getPetsByOwnerId(ownerId);
    }

    // Get pets with status = true
    @GetMapping("/lost")
    public ResponseEntity<List<Pet>> getLostPets() {
        List<Pet> lostPets = petService.getLostPets();
        return ResponseEntity.ok(lostPets);
    }

    // Add new pet for a specific owner
    @PostMapping("/owner/{ownerId}")
    public Pet addPet(@PathVariable Long ownerId, @RequestBody Pet pet) {
        return petService.addPet(ownerId, pet);
    }

    // Update a pet by pet ID
    @PutMapping("/{petId}")
    public Pet updatePet(@PathVariable Long petId, @RequestBody Pet petDetails) {
        return petService.updatePet(petId, petDetails);
    }

    // Delete a pet by pet ID
    @DeleteMapping("/{petId}")
    public void deletePet(@PathVariable Long petId) {
        petService.deletePet(petId);
    }
}
