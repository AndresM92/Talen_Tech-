package com.rum.rumBackend.controllers;

import com.rum.rumBackend.entities.Discount;
import com.rum.rumBackend.services.DiscountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/discounts")
@CrossOrigin(origins = "http://localhost:4200")
public class DiscountController {

    @Autowired
    private DiscountService discountService;

    // Create or Update a Discount
    @PostMapping
    public ResponseEntity<Discount> createDiscount(@RequestBody Discount discount) {
        Discount savedDiscount = discountService.saveDiscount(discount);
        return new ResponseEntity<>(savedDiscount, HttpStatus.CREATED);
    }

    // Get a Discount by discountId
    @GetMapping("/{discountId}")
    public ResponseEntity<Discount> getDiscountById(@PathVariable Long discountId) {
        Optional<Discount> discount = discountService.getDiscountById(discountId);
        return discount.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get all Discounts
    @GetMapping
    public ResponseEntity<List<Discount>> getAllDiscount() {
        List<Discount> discounts = discountService.getAllDiscount();
        return new ResponseEntity<>(discounts, HttpStatus.OK);
    }

    // Delete a Discount by discountId
    @DeleteMapping("/{discountId}")
    public ResponseEntity<Void> deleteDiscount(@PathVariable Long discountId) {
        discountService.deleteDiscount(discountId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // Update a Discount by discountId
    @PutMapping("/{discountId}")
    public ResponseEntity<Discount> updateDiscount(@PathVariable Long discountId, @RequestBody Discount discount) {
        Discount partialUpdateDiscount = new Discount();
        if (discount.getDiscountDescription() != null) {
            partialUpdateDiscount.setDiscountDescription(discount.getDiscountDescription());
        }
        if (discount.getValidFrom() != null) {
            partialUpdateDiscount.setValidFrom(discount.getValidFrom());
        }
        if (discount.getValidTo() != null) {
            partialUpdateDiscount.setValidTo(discount.getValidTo());
        }

        Discount updatedDiscount = discountService.updateDiscountById(discountId, partialUpdateDiscount);
        return new ResponseEntity<>(updatedDiscount, HttpStatus.OK);
    }
}
