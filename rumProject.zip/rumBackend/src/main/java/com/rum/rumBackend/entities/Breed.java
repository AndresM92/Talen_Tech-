package com.rum.rumBackend.entities;

public enum Breed {
    LABRADOR,
    BULLDOG,
    BEAGLE,
    POODLE,
    ROTTWEILER,
    DACHSHUND,
    CHIHUAHUA,
    PERSIAN,
    SIAMESE,
    BENGAL,
    SPHYNX,
    RAGDOLL
}
