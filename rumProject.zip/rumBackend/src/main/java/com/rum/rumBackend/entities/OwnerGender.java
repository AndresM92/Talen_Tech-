package com.rum.rumBackend.entities;

public enum OwnerGender {
    MASCULINO,
    FEMENINO,
    OTRO
}
