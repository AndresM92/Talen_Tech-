package com.rum.rumBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RumBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RumBackendApplication.class, args);
	}

}
