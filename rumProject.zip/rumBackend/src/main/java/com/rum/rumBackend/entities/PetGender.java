package com.rum.rumBackend.entities;

public enum PetGender {
    MACHO,
    HEMBRA
}
