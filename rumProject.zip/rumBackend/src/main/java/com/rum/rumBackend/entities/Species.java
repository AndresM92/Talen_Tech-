package com.rum.rumBackend.entities;

public enum Species {
    PERRO,
    GATO,
    AVE,
    PEZ,
    CONEJO,
    HAMSTER,
    CABRA
}
