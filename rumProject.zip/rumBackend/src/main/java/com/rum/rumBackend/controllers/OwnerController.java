package com.rum.rumBackend.controllers;

import com.rum.rumBackend.entities.Owner;
import com.rum.rumBackend.services.OwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/owners")
@CrossOrigin(origins = "http://localhost:4200")
public class OwnerController {

    @Autowired
    private OwnerService ownerService;

    // Create or Update an Owner
    @PostMapping
    public ResponseEntity<Owner> createOwner(@RequestBody Owner owner) {
        Owner savedOwner = ownerService.saveOwner(owner);
        return new ResponseEntity<>(savedOwner, HttpStatus.CREATED);
    }

    // Get an Owner by ownerId
    @GetMapping("/{ownerId}")
    public ResponseEntity<Owner> getOwnerById(@PathVariable Long ownerId) {
        Optional<Owner> owner = ownerService.getOwnerById(ownerId);
        return owner.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get all Owners
    @GetMapping
    public ResponseEntity<List<Owner>> getAllOwner() {
        List<Owner> owners = ownerService.getAllOwner();
        return new ResponseEntity<>(owners, HttpStatus.OK);
    }

    // Delete an Owner by ownerId
    @DeleteMapping("/{ownerId}")
    public ResponseEntity<Void> deleteOwner(@PathVariable Long ownerId) {
        ownerService.deleteOwner(ownerId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // Update an Owner by ownerId
    @PutMapping("/{ownerId}")
    public ResponseEntity<Owner> updateOwner(@PathVariable Long ownerId, @RequestBody Owner owner) {
        Owner partialUpdateOwner = new Owner();
        if (owner.getDocType() != null) {
            partialUpdateOwner.setDocType(owner.getDocType());
        }
        if (owner.getDocNumber() != null) {
            partialUpdateOwner.setDocNumber(owner.getDocNumber());
        }
        if (owner.getFirstName() != null) {
            partialUpdateOwner.setFirstName(owner.getFirstName());
        }
        if (owner.getLastName() != null) {
            partialUpdateOwner.setLastName(owner.getLastName());
        }
        if (owner.getOwnerGender() != null) {
            partialUpdateOwner.setOwnerGender(owner.getOwnerGender());
        }
        if (owner.getOwnerCity() != null) {
            partialUpdateOwner.setOwnerCity(owner.getOwnerCity());
        }
        if (owner.getOwnerAddress() != null) {
            partialUpdateOwner.setOwnerAddress(owner.getOwnerAddress());
        }
        if (owner.getOwnerPhonenumber() != null) {
            partialUpdateOwner.setOwnerPhonenumber(owner.getOwnerPhonenumber());
        }
        if (owner.getOwnerEmail() != null) {
            partialUpdateOwner.setOwnerEmail(owner.getOwnerEmail());
        }
        if (owner.getPassword() != null) {
            partialUpdateOwner.setPassword(owner.getPassword());
        }
        if (owner.getOwnerPhoto() != null) {
            partialUpdateOwner.setOwnerPhoto(owner.getOwnerPhoto());
        }

        Owner updatedOwner = ownerService.updateOwnerById(ownerId, partialUpdateOwner);
        return new ResponseEntity<>(updatedOwner, HttpStatus.OK);
    }
}
