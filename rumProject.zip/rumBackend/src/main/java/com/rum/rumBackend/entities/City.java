package com.rum.rumBackend.entities;

public enum City {
    CITY1,
    CITY2,
    CITY3
}
