package com.rum.rumBackend.services;

import com.rum.rumBackend.entities.Owner;
import com.rum.rumBackend.repositories.OwnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class OwnerService {

    @Autowired
    private OwnerRepository ownerRepository;

    // Insert or Update an Owner
    public Owner saveOwner(Owner owner) {
        return ownerRepository.save(owner);
    }

    // Get an Owner by ownerId
    public Optional<Owner> getOwnerById(Long ownerId) {
        return ownerRepository.findById(String.valueOf(ownerId));
    }

    // Get all Owners
    public List<Owner> getAllOwner() {
        return ownerRepository.findAll();
    }

    // Delete an Owner by ownerId
    public void deleteOwner(Long ownerId) {
        ownerRepository.deleteById(String.valueOf(ownerId));
    }

    // Update an Owner by ownerId
    public Owner updateOwnerById(Long ownerId, Owner updatedOwner) {
        // Check if Owner exists
        return ownerRepository.findById(String.valueOf(ownerId)).map(existingOwner -> {
            if (updatedOwner.getDocType() != null) {
                existingOwner.setDocType(updatedOwner.getDocType());
            }
            if (updatedOwner.getDocNumber() != null) {
                existingOwner.setDocNumber(updatedOwner.getDocNumber());
            }
            if (updatedOwner.getFirstName() != null) {
                existingOwner.setFirstName(updatedOwner.getFirstName());
            }
            if (updatedOwner.getLastName() != null) {
                existingOwner.setLastName(updatedOwner.getLastName());
            }
            if (updatedOwner.getOwnerGender() != null) {
                existingOwner.setOwnerGender(updatedOwner.getOwnerGender());
            }
            if (updatedOwner.getOwnerCity() != null) {
                existingOwner.setOwnerCity(updatedOwner.getOwnerCity());
            }
            if (updatedOwner.getOwnerAddress() != null) {
                existingOwner.setOwnerAddress(updatedOwner.getOwnerAddress());
            }
            if (updatedOwner.getOwnerPhonenumber() != null) {
                existingOwner.setOwnerPhonenumber(updatedOwner.getOwnerPhonenumber());
            }
            if (updatedOwner.getOwnerEmail() != null) {
                existingOwner.setOwnerEmail(updatedOwner.getOwnerEmail());
            }
            if (updatedOwner.getPassword() != null) {
                existingOwner.setPassword(updatedOwner.getPassword());
            }
            if (updatedOwner.getOwnerPhoto() != null) {
                existingOwner.setOwnerPhoto(updatedOwner.getOwnerPhoto());
            }

            // Save updated Owner
            return ownerRepository.save(existingOwner);
        }).orElseThrow(() -> new RuntimeException("No Owner found with ID " + ownerId));
    }
}
