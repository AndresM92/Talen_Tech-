package com.rum.rumBackend.repositories;

import com.rum.rumBackend.entities.Owner;
import com.rum.rumBackend.entities.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PetRepository extends JpaRepository<Pet, String> {
    List<Pet> findByOwner(Owner owner);
    List<Pet> findByStatus(boolean status);
}
