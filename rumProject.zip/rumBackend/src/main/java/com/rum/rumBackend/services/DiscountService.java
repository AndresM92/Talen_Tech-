package com.rum.rumBackend.services;

import com.rum.rumBackend.entities.Discount;
import com.rum.rumBackend.repositories.DiscountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class DiscountService {

    @Autowired
    private DiscountRepository discountRepository;

    // Insert or Update a Discount
    public Discount saveDiscount(Discount discount) {
        return discountRepository.save(discount);
    }

    // Get a Discount by discountId
    public Optional<Discount> getDiscountById(Long discountId) {
        return discountRepository.findById(String.valueOf(discountId));
    }

    // Get all Discounts
    public List<Discount> getAllDiscount() {
        return discountRepository.findAll();
    }

    // Delete a Discount by discountId
    public void deleteDiscount(Long discountId) {
        discountRepository.deleteById(String.valueOf(discountId));
    }

    // Update a Discount by discountId
    public Discount updateDiscountById(Long discountId, Discount updatedDiscount) {
        // Check if Discount exists
        return discountRepository.findById(String.valueOf(discountId)).map(existingDiscount -> {
            if (updatedDiscount.getDiscountDescription() != null) {
                existingDiscount.setDiscountDescription(updatedDiscount.getDiscountDescription());
            }
            if (updatedDiscount.getValidFrom() != null) {
                existingDiscount.setValidFrom(updatedDiscount.getValidFrom());
            }
            if (updatedDiscount.getValidTo() != null) {
                existingDiscount.setValidTo(updatedDiscount.getValidTo());
            }

            // Save updated Discount
            return discountRepository.save(existingDiscount);
        }).orElseThrow(() -> new RuntimeException("No Discount found with ID " + discountId));
    }
}
